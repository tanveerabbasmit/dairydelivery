/**
 * Created by Muhammad.Imran on 4/1/2016.
 */
alert('welcome');
var app = angular.module('riderDailyStockGridModule2', []);
app.controller('manageZone2', ['$scope', '$http', '$filter', function ($scope, $http, $filter) {
    //INITIALIZATION ===============================================================
    $scope.init = function (nemulist) {

      alert(nemulist);
    }






}]);



